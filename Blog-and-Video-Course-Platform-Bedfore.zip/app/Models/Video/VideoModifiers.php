<?php

namespace App\Models\Video;

trait VideoModifiers
{
//    public function getLinkAttribute()
//    {
//        return route('site.categories.show', ['slug' => slugify($this->slug)]);
//    }
//    public function getIsActiveAttribute($is_active)
//    {
//        return $is_active ? 'فعال' : 'غیرفعال' ;
//    }
}

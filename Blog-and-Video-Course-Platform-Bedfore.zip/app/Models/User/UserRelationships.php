<?php

namespace App\Models\User;

trait UserRelationships
{
}

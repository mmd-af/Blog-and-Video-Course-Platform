<?php

namespace App\Models\User;

trait UserModifiers
{

}

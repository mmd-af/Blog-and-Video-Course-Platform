<?php

namespace App\Models\Permission;

trait PermissionRelationships
{

}

<?php

namespace App\Models\Permission;

trait PermissionModifiers
{


}

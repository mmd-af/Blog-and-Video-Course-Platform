<?php

namespace App\Models\Message;

trait MessageModifiers
{

}

<?php

namespace App\Models\Message;

use App\Models\Category\Category;

trait MessageRelationships
{

}

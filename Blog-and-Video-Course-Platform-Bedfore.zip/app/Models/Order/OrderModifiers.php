<?php

namespace App\Models\Order;

trait OrderModifiers
{

}

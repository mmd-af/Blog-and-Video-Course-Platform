<?php

namespace App\Models\Role;

trait RoleModifiers
{


}

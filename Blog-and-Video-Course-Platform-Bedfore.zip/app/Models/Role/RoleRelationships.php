<?php

namespace App\Models\Role;

trait RoleRelationships
{

}

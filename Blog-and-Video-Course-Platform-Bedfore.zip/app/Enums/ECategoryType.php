<?php

namespace App\Enums;

class ECategoryType extends BaseEnum
{
    const COURSE = 1;
    const PHARMACOLOGY_POST = 2;
    const MEDICINAL_PLANTS_POST = 3;

}

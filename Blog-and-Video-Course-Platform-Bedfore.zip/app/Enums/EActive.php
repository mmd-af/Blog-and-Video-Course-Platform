<?php

namespace App\Enums;

class EActive extends BaseEnum
{
    const NO = 0;
    const YES = 1;

}

<?php

namespace App\Enums;

class EItemIsFree extends BaseEnum
{

    const PAID = 0;
    const FREE = 1;

}

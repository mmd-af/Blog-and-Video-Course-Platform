<?php

namespace App\Enums;

class EItemType extends BaseEnum
{
    const SEASON = 0;

}
